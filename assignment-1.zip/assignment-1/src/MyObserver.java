public abstract class MyObserver {
    protected MySubject subject;
    public abstract void update();
 }